# ✅ Pre-Launch Checklist

Complete this checklist before making your restaurant website public.

---

## 📞 Contact Information

### Phone Numbers
- [ ] **Header component** (`/src/app/components/Header.tsx`)
  - Replace `212XXXXXXXXX` with real phone number
  - Format: `+212 6XX XX XX XX` or preferred format

- [ ] **Contact section** (`/src/app/components/Contact.tsx`)
  - Replace `212XXXXXXXXX` with real phone number
  - Update business hours
  - Verify address text

- [ ] **Sticky Action Bar** (`/src/app/components/StickyActionBar.tsx`)
  - Replace `212XXXXXXXXX` with real phone number
  - Test "Order Now" button calls correct number

- [ ] **WhatsApp Button** (`/src/app/components/WhatsAppButton.tsx`)
  - Replace `212XXXXXXXXX` with real WhatsApp number
  - Test WhatsApp link opens correctly

### Social Media
- [ ] **Footer** (`/src/app/components/Footer.tsx`)
  - Add real Instagram handle (replace `#`)
  - Add real TikTok handle (replace `#`)
  - Verify social links work

---

## 🍔 Menu & Content

- [ ] **Menu items** (`/src/app/components/Menu.tsx`)
  - Verify all item names are correct
  - Verify all prices are accurate (in MAD)
  - Check descriptions are appealing
  - Confirm special items are highlighted

- [ ] **About section** (`/src/app/components/About.tsx`)
  - Content accurately describes restaurant
  - Tone matches brand identity

- [ ] **Hero section** (`/src/app/components/Hero.tsx`)
  - Headline is compelling
  - Call-to-action is clear

---

## 🗺️ Location & Maps

- [ ] **Google Maps** (`/src/app/components/Contact.tsx`)
  - Coordinates `7C8G+62H, Berrechid` are correct
  - Map displays correct location
  - "Navigate to Us" button works
  - Opens in Google Maps app on mobile

- [ ] **Address**
  - Physical address is complete and accurate
  - Address matches Google Maps location

---

## 📱 Mobile Testing

Test on actual mobile devices (or browser DevTools):

- [ ] **Navigation**
  - Hamburger menu opens/closes smoothly
  - All menu links work
  - Mobile menu closes after clicking link

- [ ] **Sticky Action Bar**
  - Visible at bottom on mobile
  - Doesn't cover content
  - Buttons are easy to tap

- [ ] **WhatsApp Button**
  - Visible but not intrusive
  - Opens WhatsApp correctly
  - Positioned properly on all screen sizes

- [ ] **Responsive Design**
  - Menu cards display properly
  - Images load and look good
  - Text is readable (not too small)
  - No horizontal scrolling

- [ ] **Touch Targets**
  - All buttons are large enough to tap easily
  - Links have enough spacing

---

## 🖥️ Desktop Testing

- [ ] **Navigation**
  - Desktop menu displays correctly
  - All links work
  - Hover effects work smoothly

- [ ] **Layout**
  - Content is well-spaced
  - Not too wide (max-width applied)
  - Images are high quality

- [ ] **Interactions**
  - Smooth scrolling
  - Animations are smooth
  - No layout shifts

---

## ⚡ Performance

- [ ] **Page Load Speed**
  - Test on [PageSpeed Insights](https://pagespeed.web.dev/)
  - Mobile score > 80
  - Desktop score > 90

- [ ] **Images**
  - All images load quickly
  - Images are optimized (not too large)
  - No broken image links

---

## 🔍 SEO & Meta Tags

Check in `/index.html` (or main HTML file):

- [ ] **Page Title**
  - Includes restaurant name
  - Includes location (Berrechid)
  - Example: "The Chefs - Gourmet Restaurant in Berrechid, Morocco"

- [ ] **Meta Description**
  - Compelling description (150-160 characters)
  - Includes keywords: restaurant, Berrechid, burgers, tacos, etc.

- [ ] **Favicon**
  - Restaurant logo appears in browser tab
  - Looks good on bookmarks

---

## 🔗 Links & Buttons

Test every clickable element:

- [ ] **Header Links**
  - Home → Scrolls to top
  - Menu → Scrolls to menu
  - About → Scrolls to about
  - Contact → Scrolls to contact

- [ ] **Call-to-Action Buttons**
  - "Order Now" → Calls restaurant
  - "Navigate to Us" → Opens Google Maps
  - "Menu" button → Scrolls to menu section

- [ ] **Social Media Icons**
  - Instagram → Opens Instagram profile
  - TikTok → Opens TikTok profile

- [ ] **WhatsApp Button**
  - Opens WhatsApp with pre-filled message
  - Works on mobile and desktop

---

## 🌐 Browser Testing

Test on multiple browsers:

- [ ] **Chrome** (most users)
  - Desktop ✅
  - Mobile ✅

- [ ] **Safari** (iPhone users)
  - Desktop ✅
  - Mobile ✅

- [ ] **Firefox**
  - Desktop ✅

- [ ] **Edge**
  - Desktop ✅

---

## 🎨 Visual Quality

- [ ] **Colors**
  - Dark theme is consistent
  - Burnt orange accents stand out
  - Good contrast for readability

- [ ] **Typography**
  - Text is readable on all devices
  - Headings are clear and prominent
  - No text overlapping

- [ ] **Images**
  - High quality (not pixelated)
  - Appropriate for restaurant
  - Consistent style

- [ ] **Spacing**
  - Sections have proper spacing
  - Not too cramped
  - Not too much white space

---

## 🔒 Security & Privacy

- [ ] **HTTPS**
  - Site loads with `https://`
  - No mixed content warnings
  - SSL certificate valid

- [ ] **Privacy**
  - No sensitive data exposed
  - Contact form (if any) is secure

---

## 📊 Analytics & Tracking (Optional)

- [ ] **Google Analytics** (optional)
  - Tracking code added
  - Testing shows data collection

- [ ] **Facebook Pixel** (optional)
  - Pixel installed
  - Events configured

---

## 🚀 Deployment

- [ ] **Build Settings**
  - If using GitHub Pages: `vite.config.ts` has correct repo name
  - Build command works: `npm run build`
  - No build errors

- [ ] **Environment**
  - Production environment set
  - No debug/console logs in production
  - No test data visible

- [ ] **Domain**
  - Custom domain configured (if using)
  - DNS records propagated
  - HTTPS working on custom domain

---

## 📢 Launch Preparation

- [ ] **Soft Launch** (recommended)
  - Share with friends/family first
  - Get feedback
  - Fix any issues found

- [ ] **Announcement Ready**
  - Social media posts prepared
  - Google My Business updated
  - Staff informed about website

---

## 🎯 Final Tests

**The Ultimate Test:**
1. Clear your browser cache
2. Use private/incognito mode
3. Visit your site on mobile
4. Pretend you're a customer:
   - Can you easily find menu?
   - Can you call to order?
   - Can you find location?
   - Is it appealing?

**If you answer YES to all → You're ready to launch! 🚀**

---

## 📋 Post-Launch

Within first week:

- [ ] **Monitor Performance**
  - Check load times
  - Watch for errors
  - Monitor uptime

- [ ] **Gather Feedback**
  - Ask customers
  - Monitor social media
  - Check analytics

- [ ] **Quick Fixes**
  - Fix any bugs found
  - Update info if needed
  - Optimize based on feedback

---

## 🎉 Launch Day!

When everything is checked:

1. **Final build:** `npm run build`
2. **Deploy** to production
3. **Verify** live site works
4. **Announce** on social media
5. **Celebrate!** 🎊

---

**Your restaurant website is ready to serve customers online! 🍔🌮🍕**

---

## 📞 Emergency Contacts

If something goes wrong after launch:

- **Hosting Issues:** Check platform status page
  - GitHub: [githubstatus.com](https://www.githubstatus.com/)
  - Netlify: [netlifystatus.com](https://www.netlifystatus.com/)

- **DNS/Domain Issues:** Contact your domain registrar

- **Code Issues:** Check browser console for errors

---

**Keep this checklist for future updates!**
