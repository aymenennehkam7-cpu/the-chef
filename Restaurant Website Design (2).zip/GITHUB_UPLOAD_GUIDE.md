# 📤 How to Upload Your Code to GitHub

Simple step-by-step guide for beginners.

## 🎯 Method 1: GitHub Desktop (Easiest - No Commands!)

### Step 1: Download GitHub Desktop
1. Go to [https://desktop.github.com/](https://desktop.github.com/)
2. Download and install GitHub Desktop
3. Open it and sign in with your GitHub account (create one if needed)

### Step 2: Create Repository on GitHub Website
1. Go to [https://github.com](https://github.com)
2. Click the **green "New"** button (top left)
3. Repository name: `the-chefs-restaurant`
4. Description: `Modern restaurant website for The Chefs - Berrechid, Morocco`
5. Keep it **Public** ✅
6. **DON'T** check "Add README" (we already have one)
7. Click **"Create repository"**

### Step 3: Upload Your Code
1. In GitHub Desktop, click **"File" → "Add Local Repository"**
2. Click **"Choose"** and select your project folder
3. If it says "This directory does not appear to be a git repository":
   - Click **"Create a repository"**
   - Click **"Create Repository"** again
4. Click **"Publish repository"** (top right)
5. Uncheck **"Keep this code private"** if you want free GitHub Pages
6. Click **"Publish Repository"**

### Step 4: Done! 🎉
Your code is now on GitHub! To deploy it, see [DEPLOY_GITHUB.md](./DEPLOY_GITHUB.md)

---

## 🎯 Method 2: Command Line (For Developers)

### Step 1: Install Git
- **Windows:** Download from [git-scm.com](https://git-scm.com/)
- **Mac:** Open Terminal, type `git --version` (will auto-install)
- **Linux:** `sudo apt-get install git`

### Step 2: Create Repository on GitHub
1. Go to [https://github.com](https://github.com)
2. Click **"New"** repository
3. Name: `the-chefs-restaurant`
4. Public ✅
5. Don't add README
6. Click **"Create repository"**

### Step 3: Upload Code (Copy-Paste These Commands)

Open Terminal/Command Prompt in your project folder:

```bash
# Initialize git
git init

# Add all files
git add .

# Create first commit
git commit -m "Initial commit: The Chefs Restaurant website"

# Add your GitHub repository (REPLACE YOUR-USERNAME!)
git remote add origin https://github.com/YOUR-USERNAME/the-chefs-restaurant.git

# Set main branch
git branch -M main

# Push to GitHub
git push -u origin main
```

**Important:** Replace `YOUR-USERNAME` with your actual GitHub username!

### Step 4: Enter Credentials
- GitHub will ask for username and password
- **NOTE:** Use a **Personal Access Token** instead of password
  - Go to GitHub → Settings → Developer settings → Personal access tokens
  - Generate new token (classic)
  - Copy it and use as password

---

## 🔄 Future Updates (After First Upload)

### Using GitHub Desktop:
1. Make changes to your files
2. Open GitHub Desktop
3. It will show changed files
4. Add a message (e.g., "Updated menu prices")
5. Click **"Commit to main"**
6. Click **"Push origin"**

### Using Command Line:
```bash
git add .
git commit -m "Your change description"
git push
```

---

## ✅ Verify Upload Success

1. Go to your repository on GitHub
2. You should see all your files listed
3. README.md should be displayed at the bottom

**Next Step:** Deploy your site! See [DEPLOY_GITHUB.md](./DEPLOY_GITHUB.md)

---

## 🐛 Common Issues

### "Git is not recognized"
- **Fix:** Install Git from [git-scm.com](https://git-scm.com/)
- Restart your terminal/command prompt

### "Permission denied"
- **Fix:** Use HTTPS URL (not SSH) for repository
- Use Personal Access Token as password

### "Repository already exists"
- **Fix:** Use a different repository name
- Or delete the existing one and create new

### Files too large
- **Fix:** Don't upload `node_modules` folder
- Make sure `.gitignore` file is in your project

---

## 📁 What Gets Uploaded?

✅ **YES - These get uploaded:**
- `/src` folder (all your code)
- `package.json`
- `vite.config.ts`
- `README.md`
- `.gitignore`
- `netlify.toml`
- All other config files

❌ **NO - These don't (and shouldn't):**
- `node_modules` (too large, auto-installed)
- `dist` (build folder, auto-generated)
- `.env` files (secrets)

---

## 🎓 Learn More

- [GitHub Docs](https://docs.github.com/en/get-started)
- [Git Tutorial](https://git-scm.com/docs/gittutorial)
- [GitHub Desktop Help](https://docs.github.com/en/desktop)

---

**Ready to deploy? See [DEPLOY_GITHUB.md](./DEPLOY_GITHUB.md)!** 🚀
