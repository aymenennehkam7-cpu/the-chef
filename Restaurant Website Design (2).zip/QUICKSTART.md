# ⚡ Quick Start Guide

Get your restaurant website live in minutes!

## 🎯 Choose Your Path

### Path 1: "I Want It Live NOW!" (30 seconds)
**Best for:** Complete beginners, testing

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Build the site:**
   ```bash
   npm run build
   ```

3. **Deploy:**
   - Go to [https://app.netlify.com/drop](https://app.netlify.com/drop)
   - Drag the `dist` folder that was created
   - **DONE!** Your site is live!

---

### Path 2: "I Want Professional Setup" (10 minutes)
**Best for:** Long-term use, automatic updates

**Step 1: Choose Platform**
- **GitHub Pages:** Free, integrates with GitHub → [Guide](./DEPLOY_GITHUB.md)
- **Netlify:** Free, easiest → [Guide](./README.md#option-2-netlify)
- **Not sure?** → [Compare them](./DEPLOYMENT_COMPARISON.md)

**Step 2: Upload to GitHub** (needed for both)
- [📤 Upload Guide](./GITHUB_UPLOAD_GUIDE.md)

**Step 3: Deploy**
- **GitHub Pages:** [Full guide](./DEPLOY_GITHUB.md)
- **Netlify:** Connect your GitHub repo

---

## 📝 Before Going Live Checklist

Replace placeholder contact info:

- [ ] **Phone number** - Search for `212XXXXXXXXX` in:
  - `/src/app/components/Header.tsx`
  - `/src/app/components/Contact.tsx`
  - `/src/app/components/StickyActionBar.tsx`
  - `/src/app/components/WhatsAppButton.tsx`

- [ ] **Social media** - Update in `/src/app/components/Footer.tsx`:
  - Instagram handle
  - TikTok handle

- [ ] **Business hours** - Update in `/src/app/components/Contact.tsx`

- [ ] **Menu prices** - Verify in `/src/app/components/Menu.tsx`

---

## 🧪 Test Locally First

Before deploying, test everything works:

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

Open your browser to `http://localhost:5173` and check:
- ✅ Menu displays correctly
- ✅ Contact form works
- ✅ Google Maps loads
- ✅ WhatsApp button works
- ✅ All links work
- ✅ Mobile view looks good (resize browser)

---

## 🚀 Deployment Comparison

| Method | Time | Difficulty | Updates |
|--------|------|------------|---------|
| **Netlify Drop** | 30 sec | ⭐ Easy | Manual re-upload |
| **Netlify + GitHub** | 5 min | ⭐⭐ Medium | Auto on git push |
| **GitHub Pages** | 10 min | ⭐⭐⭐ Medium+ | Auto on git push |

---

## 🎓 Learning Path

**Complete Beginner?**
1. Start with **Netlify Drop** (30 seconds)
2. Test your live site
3. Update contact info
4. Learn git later
5. Move to GitHub + auto-deploy

**Some Experience?**
1. Upload to GitHub
2. Deploy with Netlify (easier)
3. Later try GitHub Pages

**Experienced Developer?**
1. GitHub Pages with GitHub Actions
2. Set up custom domain
3. Configure CI/CD pipeline

---

## 📚 Documentation Index

**Getting Started:**
- [📖 Main README](./README.md) - Overview & features
- [⚡ This Quick Start](./QUICKSTART.md) - You are here!
- [📊 Deployment Comparison](./DEPLOYMENT_COMPARISON.md) - Which to choose?

**Deployment Guides:**
- [📤 Upload to GitHub](./GITHUB_UPLOAD_GUIDE.md) - Step-by-step
- [🚀 GitHub Pages Deploy](./DEPLOY_GITHUB.md) - Complete guide
- [⚡ Netlify Deploy](./README.md#option-2-netlify) - In main README

**Configuration:**
- [⚙️ Vite Config](./vite.config.ts) - Build settings
- [🌐 Netlify Config](./netlify.toml) - Netlify settings
- [🔧 GitHub Actions](./.github/workflows/deploy.yml) - Auto-deploy

---

## 🆘 Common Issues

### "npm: command not found"
**Fix:** Install Node.js from [nodejs.org](https://nodejs.org/)

### Build fails
**Fix:** 
```bash
# Delete node_modules and reinstall
rm -rf node_modules
npm install
npm run build
```

### Site shows blank page
**Fix:** 
- Check browser console for errors
- Clear browser cache
- Make sure you uploaded the `dist` folder, not the whole project

### Assets not loading (GitHub Pages)
**Fix:** 
- Update `vite.config.ts` with correct repository name
- Rebuild: `npm run build`
- Redeploy

---

## ✅ Success Checklist

Your site is ready when:

- [ ] Site loads in browser
- [ ] Menu displays with prices
- [ ] Google Maps shows Berrechid location
- [ ] WhatsApp button opens WhatsApp
- [ ] "Order Now" button calls correct number
- [ ] "Navigate to Us" opens Google Maps
- [ ] Social media links work
- [ ] Mobile view looks good
- [ ] All images load

---

## 🎉 You're Ready!

Pick your path above and get started. Your restaurant website will be live in minutes!

**Questions?** Check the specific guides linked above.

**Ready to customize?** All component files are in `/src/app/components/`

---

**Good luck with The Chefs Restaurant! 🍔🌮🍕**
