Ce fichier Figma Make comprend des composants de [shadcn/ui](https://ui.shadcn.com/) utilisés sous [licence MIT](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

Ce fichier Figma Make inclut des photos de [Unsplash](https://unsplash.com) utilisées sous [licence](https://unsplash.com/license).