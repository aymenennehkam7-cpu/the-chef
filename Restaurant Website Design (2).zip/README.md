# The Chefs Restaurant - Berrechid, Morocco

Modern, mobile-first restaurant website featuring industrial chic aesthetic with dark tones and burnt orange accents.

> **🎯 New to this project?** Start here: **[START_HERE.md](./START_HERE.md)** - Your quick guide to deploying this website!

---

## 📚 Complete Documentation

**New to this project?** Check the **[📖 Documentation Index](./DOCUMENTATION_INDEX.md)** for a complete guide to all documentation files and where to start based on your needs.

## 🚀 Quick Links

- **⚡ [Quick Start Guide](./QUICKSTART.md)** - Get live in 30 seconds!
- **📋 [Pre-Launch Checklist](./PRE_LAUNCH_CHECKLIST.md)** - Everything to check before going live
- **📊 [Deployment Comparison](./DEPLOYMENT_COMPARISON.md)** - GitHub Pages vs Netlify
- **📤 [GitHub Upload Guide](./GITHUB_UPLOAD_GUIDE.md)** - How to upload your code
- **🚀 [GitHub Pages Deploy](./DEPLOY_GITHUB.md)** - Full deployment guide
- **📝 [GitHub Deployment Summary](./GITHUB_DEPLOYMENT_SUMMARY.md)** - Quick reference

---

## 🚀 Quick Deploy Options

Choose your preferred deployment method:

### 🎯 Option 1: GitHub Pages (FREE - Best for GitHub Users)
**Your site URL:** `https://YOUR-USERNAME.github.io/the-chefs-restaurant/`

📖 **[Complete GitHub Pages Guide →](./DEPLOY_GITHUB.md)**

**Quick Steps:**
1. Upload code to GitHub ([Upload Guide](./GITHUB_UPLOAD_GUIDE.md))
2. Enable GitHub Pages in Settings → Pages → Source: "GitHub Actions"
3. Auto-deploys on every push!

### 🎯 Option 2: Netlify (FREE - Easiest & Fastest)
**Your site URL:** Custom Netlify subdomain

**Method A: Drag & Drop (30 seconds)**
1. Build locally: `npm install && npm run build`
2. Go to [Netlify Drop](https://app.netlify.com/drop)
3. Drag the `dist` folder
4. Done!

**Method B: GitHub Integration (Auto-updates)**
1. Push code to GitHub
2. Go to [Netlify](https://app.netlify.com/)
3. "Add new site" → "Import from GitHub"
4. Auto-deploys on every push!

## 🛠️ Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## 📋 Before Going Live

**Update Contact Information in these files:**

1. **`/src/app/components/Header.tsx`** - Phone number
2. **`/src/app/components/Contact.tsx`** - Phone number, address, hours
3. **`/src/app/components/Footer.tsx`** - Social media handles (Instagram, TikTok)
4. **`/src/app/components/StickyActionBar.tsx`** - Phone number
5. **`/src/app/components/WhatsAppButton.tsx`** - WhatsApp number

**Search for:** `212XXXXXXXXX` and replace with actual phone number

## 🌟 Features

- ✅ Mobile-first responsive design
- ✅ Hamburger navigation menu
- ✅ Sticky bottom action bar (Order Now + Navigate)
- ✅ Floating WhatsApp button
- ✅ Google Maps integration (7C8G+62H, Berrechid)
- ✅ Full menu with pricing (MAD)
- ✅ SEO optimized for Berrechid searches
- ✅ Industrial chic dark theme
- ✅ Burnt orange accent colors

## 📱 Menu Sections

- Chef's Burgers
- Premium Tacos
- Italian Corner (Pizza & Pasta)
- Grills
- Salads & Starters

## 🔧 Tech Stack

- React 18
- Vite
- Tailwind CSS
- Lucide Icons
- Material UI

## 📞 Support

For questions or support, contact the restaurant at the number provided on the website.

---

**Built with ❤️ for The Chefs Restaurant**