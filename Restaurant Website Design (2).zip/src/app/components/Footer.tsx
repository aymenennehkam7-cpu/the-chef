import { ChefHat } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-black py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ChefHat className="w-6 h-6 text-orange-500" />
            <span className="text-white">The Chefs</span>
          </div>
          
          <p className="text-zinc-500 text-sm text-center">
            © 2026 The Chefs Berrechid. All rights reserved.
          </p>

          <p className="text-zinc-600 text-sm">
            Restaurant quality at fast-food speed
          </p>
        </div>
      </div>
    </footer>
  );
}
