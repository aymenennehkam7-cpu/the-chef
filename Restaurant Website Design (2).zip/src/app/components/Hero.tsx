import { ImageWithFallback } from './figma/ImageWithFallback';

export function Hero() {
  const scrollToMenu = () => {
    const element = document.getElementById('menu');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1700835880832-dcdecf739e36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwcHJlcGFyaW5nJTIwZ291cm1ldCUyMGJ1cmdlcnxlbnwxfHx8fDE3NjcyOTI2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Chef preparing gourmet burger"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-zinc-900/70 via-zinc-900/50 to-zinc-900/90" />
      </div>
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-white text-5xl md:text-7xl mb-6">
          The Art of Taste in Berrechid
        </h1>
        <p className="text-zinc-200 text-xl md:text-2xl mb-8">
          Experience gourmet flavors prepared by passionate chefs
        </p>
        <button
          onClick={scrollToMenu}
          className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg transition-all transform hover:scale-105 shadow-lg"
        >
          See Our Menu
        </button>
      </div>
    </section>
  );
}
