import { ImageWithFallback } from './figma/ImageWithFallback';

interface MenuItem {
  name: string;
  description: string;
  price: string;
  image?: string;
}

interface MenuSectionProps {
  title: string;
  icon: React.ReactNode;
  items: MenuItem[];
  subtitle?: string;
}

export function MenuSection({ title, icon, items, subtitle }: MenuSectionProps) {
  return (
    <div className="mb-16">
      <div className="flex items-center gap-3 mb-2">
        <div className="text-orange-500">
          {icon}
        </div>
        <h3 className="text-3xl text-zinc-900">{title}</h3>
      </div>
      {subtitle && (
        <p className="text-zinc-600 mb-6 ml-12">{subtitle}</p>
      )}
      
      <div className="grid md:grid-cols-2 gap-6">
        {items.map((item, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow">
            {item.image && (
              <ImageWithFallback
                src={item.image}
                alt={item.name}
                className="w-full h-48 object-cover"
              />
            )}
            <div className="p-6">
              <div className="flex justify-between items-start mb-2">
                <h4 className="text-xl text-zinc-900">{item.name}</h4>
                <span className="text-orange-500 ml-4 whitespace-nowrap">{item.price}</span>
              </div>
              <p className="text-zinc-600">{item.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
