import { useState } from 'react';
import { Menu, X, ChefHat } from 'lucide-react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 bg-zinc-900/95 backdrop-blur-sm z-50 border-b border-zinc-800">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <button onClick={() => scrollToSection('hero')} className="flex items-center gap-2">
            <ChefHat className="w-8 h-8 text-orange-500" />
            <span className="text-white text-xl">The Chefs</span>
          </button>
          
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="text-white p-2 hover:bg-zinc-800 rounded-lg transition-colors lg:hidden"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          <nav className="hidden lg:flex items-center gap-6">
            <button onClick={() => scrollToSection('about')} className="text-white hover:text-orange-500 transition-colors">About</button>
            <button onClick={() => scrollToSection('menu')} className="text-white hover:text-orange-500 transition-colors">Menu</button>
            <button onClick={() => scrollToSection('contact')} className="text-white hover:text-orange-500 transition-colors">Contact</button>
          </nav>
        </div>
      </header>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 bg-zinc-900 z-40 pt-20 lg:hidden">
          <nav className="flex flex-col items-center gap-8 p-8">
            <button
              onClick={() => scrollToSection('about')}
              className="text-white text-2xl hover:text-orange-500 transition-colors"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection('menu')}
              className="text-white text-2xl hover:text-orange-500 transition-colors"
            >
              Menu
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="text-white text-2xl hover:text-orange-500 transition-colors"
            >
              Contact
            </button>
          </nav>
        </div>
      )}
    </>
  );
}
