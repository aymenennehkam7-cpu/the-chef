import { MenuSection } from './MenuSection';
import { Beef, Pizza, Salad, UtensilsCrossed } from 'lucide-react';

export function Menu() {
  const burgers = [
    {
      name: "The Signature",
      description: "Black Angus beef, caramelized onions, cheddar, chef's secret sauce",
      price: "65 MAD",
      image: "https://images.unsplash.com/photo-1676300187304-7f9b3c97ee8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwYnVyZ2VyJTIwY2xvc2UlMjB1cHxlbnwxfHx8fDE3NjcyOTI2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      name: "The Crispy",
      description: "Breaded chicken breast, coleslaw, spicy mayo",
      price: "55 MAD"
    },
    {
      name: "The Smoky",
      description: "Beef patty, bbq sauce, beef bacon, smoked cheese",
      price: "70 MAD"
    }
  ];

  const tacos = [
    {
      name: "Minced Meat Taco",
      description: "Savory minced beef with our signature homemade cheese sauce",
      price: "Regular: 25 MAD | Mega: 35 MAD | Giga: 45 MAD",
      image: "https://images.unsplash.com/photo-1618215701925-100abf073bf0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwdGFjb3MlMjBmb29kfGVufDF8fHx8MTc2NzI5MjY1M3ww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      name: "Chicken Curry Taco",
      description: "Tender chicken in aromatic curry spices with cheese sauce",
      price: "Regular: 25 MAD | Mega: 35 MAD | Giga: 45 MAD"
    },
    {
      name: "Merguez Taco",
      description: "Spicy North African sausage with our homemade cheese sauce",
      price: "Regular: 30 MAD | Mega: 40 MAD | Giga: 50 MAD"
    },
    {
      name: "Cordon Bleu Taco",
      description: "Breaded chicken filled with cheese and turkey, topped with our signature sauce",
      price: "Regular: 35 MAD | Mega: 45 MAD | Giga: 55 MAD"
    }
  ];

  const italian = [
    {
      name: "Margherita Pizza",
      description: "Thin crust, mozzarella fior di latte, fresh basil, tomato sauce",
      price: "60 MAD",
      image: "https://images.unsplash.com/photo-1760538635911-dee3b46f2011?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwcGl6emElMjByZXN0YXVyYW50fGVufDF8fHx8MTc2NzI1NzYwMXww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      name: "Pepperoni Pizza",
      description: "Classic pepperoni with mozzarella on thin crust",
      price: "70 MAD"
    },
    {
      name: "4 Cheese Pizza",
      description: "Mozzarella, gorgonzola, parmesan, and smoked cheese blend",
      price: "75 MAD"
    },
    {
      name: "Tagliatelle Alfredo",
      description: "Fresh tagliatelle in creamy parmesan sauce",
      price: "55 MAD",
      image: "https://images.unsplash.com/photo-1627207644206-a2040d60ecad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXN0YSUyMGNhcmJvbmFyYSUyMGRpc2h8ZW58MXx8fHwxNzY3MTcyMDg5fDA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      name: "Penne Arrabbiata",
      description: "Penne pasta in spicy tomato sauce with garlic",
      price: "50 MAD"
    },
    {
      name: "Spaghetti Carbonara (Halal)",
      description: "Classic carbonara with eggs, parmesan, and turkey bacon",
      price: "60 MAD"
    }
  ];

  const salads = [
    {
      name: "Caesar Salad",
      description: "Romaine lettuce, parmesan, croutons, Caesar dressing",
      price: "40 MAD",
      image: "https://images.unsplash.com/photo-1739436776460-35f309e3f887?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGNhZXNhciUyMHNhbGFkfGVufDF8fHx8MTc2NzI5MjY1NXww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      name: "Niçoise Salad",
      description: "Tuna, eggs, green beans, tomatoes, olives, anchovies",
      price: "45 MAD"
    },
    {
      name: "Mozzarella Sticks",
      description: "Crispy breaded mozzarella with marinara sauce",
      price: "35 MAD"
    },
    {
      name: "Chicken Wings",
      description: "Spicy or BBQ glazed chicken wings (6 pieces)",
      price: "40 MAD"
    }
  ];

  return (
    <section id="menu" className="bg-white py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-orange-500 text-sm uppercase tracking-wider mb-4">Our Menu</h2>
          <h3 className="text-4xl md:text-5xl mb-4 text-zinc-900">Gourmet Flavors</h3>
          <p className="text-zinc-600 max-w-2xl mx-auto">
            Every dish is prepared fresh by our chefs using premium ingredients
          </p>
        </div>

        <MenuSection
          title="Chef's Burgers"
          icon={<Beef className="w-8 h-8" />}
          items={burgers}
        />

        <MenuSection
          title="Premium Tacos"
          icon={<UtensilsCrossed className="w-8 h-8" />}
          items={tacos}
          subtitle="Featuring our signature homemade cheese sauce (Sauce Fromagère Maison)"
        />

        <MenuSection
          title="Italian Corner"
          icon={<Pizza className="w-8 h-8" />}
          items={italian}
        />

        <MenuSection
          title="Salads & Starters"
          icon={<Salad className="w-8 h-8" />}
          items={salads}
        />
      </div>
    </section>
  );
}
