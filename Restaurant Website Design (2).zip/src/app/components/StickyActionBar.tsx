import { ShoppingBag, Navigation } from 'lucide-react';

export function StickyActionBar() {
  const handleOrder = () => {
    // Link to delivery service or WhatsApp order
    window.open('https://wa.me/212XXXXXXXXX?text=Hello! I would like to place an order.', '_blank');
  };

  const handleNavigate = () => {
    window.open('https://maps.google.com/?q=7C8G+62H,Berrechid', '_blank');
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-zinc-900 border-t border-zinc-800 z-50 md:hidden">
      <div className="grid grid-cols-2 gap-2 p-3">
        <button
          onClick={handleOrder}
          className="bg-orange-500 hover:bg-orange-600 text-white py-4 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
        >
          <ShoppingBag className="w-5 h-5" />
          <span>Order Now</span>
        </button>
        <button
          onClick={handleNavigate}
          className="bg-zinc-700 hover:bg-zinc-600 text-white py-4 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
        >
          <Navigation className="w-5 h-5" />
          <span>Navigate</span>
        </button>
      </div>
    </div>
  );
}
