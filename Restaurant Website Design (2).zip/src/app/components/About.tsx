import { ImageWithFallback } from './figma/ImageWithFallback';
import { ChefHat, Beef, Users } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="bg-zinc-50 py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-orange-500 text-sm uppercase tracking-wider mb-4">Notre Passion</h2>
            <h3 className="text-4xl md:text-5xl mb-6 text-zinc-900">Meet The Chefs</h3>
            
            <div className="prose prose-lg text-zinc-700 space-y-4 mb-8">
              <p>
                Welcome to <strong>"The Chefs"</strong> – Berrechid
              </p>
              <p>
                We believe that great food starts with great ingredients and skilled hands. At "The Chefs," we have elevated the dining experience in Berrechid by combining the speed of service with the quality of a gastronomic kitchen.
              </p>
              <p>
                Our team doesn't just assemble food; we cook it. From our homemade marinades to our locally sourced fresh vegetables and premium meats, every bite is a testament to our passion for culinary arts.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-6">
              <div className="flex items-start gap-4">
                <div className="bg-orange-500 p-3 rounded-lg">
                  <ChefHat className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-zinc-900 mb-1">Chef-Curated Recipes</h4>
                  <p className="text-zinc-600">Unique flavor combinations you won't find elsewhere</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-orange-500 p-3 rounded-lg">
                  <Beef className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-zinc-900 mb-1">Quality Commitment</h4>
                  <p className="text-zinc-600">Fresh meat, never frozen</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-orange-500 p-3 rounded-lg">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-zinc-900 mb-1">Family Friendly</h4>
                  <p className="text-zinc-600">A clean, modern atmosphere perfect for families and friends</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1512149519538-136d1b8c574a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBraXRjaGVuJTIwY2hlZnxlbnwxfHx8fDE3NjcyNTI5MDV8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Professional chef in kitchen"
                className="w-full h-64 object-cover rounded-lg shadow-lg"
              />
            </div>
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1676300187304-7f9b3c97ee8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwYnVyZ2VyJTIwY2xvc2UlMjB1cHxlbnwxfHx8fDE3NjcyOTI2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Gourmet burger"
              className="w-full h-48 object-cover rounded-lg shadow-lg"
            />
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1613274554329-70f997f5789f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwaW50ZXJpb3IlMjBtb2Rlcm58ZW58MXx8fHwxNzY3MjE5MjEzfDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Modern restaurant interior"
              className="w-full h-48 object-cover rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
