# 🚀 Deploy to GitHub Pages

Complete guide to deploy your restaurant website to GitHub Pages for **FREE**.

## 📋 Prerequisites

- GitHub account (free)
- Git installed on your computer
- Your website code ready

## ⚙️ Important: Configure Your Repository Name

**BEFORE uploading to GitHub**, update the repository name in `vite.config.ts`:

1. Open `/vite.config.ts`
2. Find this line: `base: process.env.GITHUB_PAGES ? '/the-chefs-restaurant/' : '/',`
3. Replace `'the-chefs-restaurant'` with YOUR repository name
4. Example: If your repo is `my-restaurant`, use `'/my-restaurant/'`
5. Save the file

**This step is CRITICAL for GitHub Pages to work correctly!**

## 🎯 Step-by-Step Deployment

### Step 1: Create GitHub Repository

1. Go to [GitHub](https://github.com)
2. Click the **"+"** icon → **"New repository"**
3. Name it: `the-chefs-restaurant` (or any name you want)
4. Keep it **Public** (required for free GitHub Pages)
5. **Don't** initialize with README (we already have one)
6. Click **"Create repository"**

### Step 2: Upload Your Code

**Option A: Using GitHub Desktop (Easiest)**

1. Download [GitHub Desktop](https://desktop.github.com/)
2. Open GitHub Desktop
3. File → Add Local Repository → Select your project folder
4. If it says "not a git repository", click "Create a repository here"
5. Click "Publish repository" button
6. Done!

**Option B: Using Command Line**

Open terminal/command prompt in your project folder:

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit files
git commit -m "Initial commit - The Chefs Restaurant website"

# Connect to your GitHub repository
git remote add origin https://github.com/YOUR-USERNAME/the-chefs-restaurant.git

# Push to GitHub
git branch -M main
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username.

### Step 3: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **"Settings"** tab (top right)
3. Click **"Pages"** in the left sidebar
4. Under "Build and deployment":
   - **Source:** Select "GitHub Actions"
5. Click **"Save"**

### Step 4: Automatic Deployment

The GitHub Action will automatically:
- ✅ Install dependencies
- ✅ Build your website
- ✅ Deploy to GitHub Pages

**Your site will be live at:**
```
https://YOUR-USERNAME.github.io/the-chefs-restaurant/
```

## 🔄 Future Updates

Every time you push changes to GitHub, the site automatically rebuilds and deploys!

```bash
# Make your changes to files
# Then:
git add .
git commit -m "Updated menu prices"
git push
```

Wait 1-2 minutes and your site updates automatically! 🎉

## 🌐 Custom Domain (Optional)

Want to use your own domain like `www.thechefs.ma`?

1. Buy a domain from a registrar (e.g., GoDaddy, Namecheap)
2. In GitHub repository → Settings → Pages
3. Add your custom domain
4. Follow GitHub's instructions to configure DNS

## ⚠️ Important Notes

- **Repository must be Public** for free GitHub Pages
- First deployment takes 2-5 minutes
- Check the **"Actions"** tab to see deployment progress
- If deployment fails, check the Actions tab for errors

## 🆚 GitHub Pages vs Netlify

| Feature | GitHub Pages | Netlify |
|---------|--------------|---------|
| **Price** | Free | Free |
| **Custom Domain** | ✅ Yes | ✅ Yes |
| **Auto Deploy** | ✅ Yes | ✅ Yes |
| **Build Time** | 2-5 min | 1-2 min |
| **Ease of Setup** | Medium | Easiest |
| **Best For** | GitHub users | Quick deploys |

**Recommendation:** Use **Netlify** for easiest deployment, or **GitHub Pages** if you prefer keeping everything on GitHub.

## 🐛 Troubleshooting

### Deployment Failed?
- Check the "Actions" tab for error details
- Make sure `package.json` has the build script
- Verify all dependencies are in `package.json`

### Site Shows 404?
- Wait 5 minutes after first deployment
- Check Settings → Pages to confirm it's enabled
- Clear your browser cache

### Changes Not Showing?
- Check Actions tab - deployment might still be running
- Hard refresh your browser (Ctrl+Shift+R or Cmd+Shift+R)
- Wait 2-3 minutes for GitHub's CDN to update

## 📞 Need Help?

Check GitHub's official docs: [GitHub Pages Documentation](https://docs.github.com/en/pages)

---

**Your website will be live and accessible worldwide! 🌍**